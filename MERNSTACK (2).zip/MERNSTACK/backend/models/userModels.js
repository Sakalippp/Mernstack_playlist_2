const mongoose = require('mongoose')
const bcrypt = require('bcrypt')
const validator = require('validator')

const Schema = mongoose.Schema

const userSchema = new Schema({
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    }
})

// Metode statis signup
userSchema.statics.signup = async function(email, password) {
    // Validasi
    if (!email || !password) {
        throw Error('Semua kolom harus diisi')
    }
    if (!validator.isEmail(email)){
        throw Error('Email tidak valid')
    }
    if (!validator.isStrongPassword(password)) {
        throw Error('Password tidak cukup kuat')
    }

    const exists = await this.findOne({ email })
    if (exists) {
        throw Error('Email sudah digunakan')
    }

    // Generate salt dan hash password
    const salt = await bcrypt.genSalt(10)
    const hash = await bcrypt.hash(password, salt)
    
    // Buat pengguna dengan password yang di-hash
    const user = await this.create({ email, password: hash })

    return user
}

// Metode statis login
userSchema.statics.login = async function(email, password) {
    if (!email || !password) {
        throw Error('Semua kolom harus diisi')
    }

    const user = await this.findOne({ email })

    if (!user) {
        throw Error('Email tidak ditemukan')
    }

    const match = await bcrypt.compare(password, user.password)

    if (!match) {
        throw Error('Password salah')
    }

    return user
}

module.exports = mongoose.model('User', userSchema)
